class PKDriver {		
   public static void main (String argv[]){
      PKGUI pkbattle = new PKGUI(); 
      
   }
}

